import gradio as gr

import motor

REGRAS = motor.carregar_regras()
UNIDADES = motor.carregar_unidades()
POR_ID = {s["id"]: s for s in REGRAS}


def perguntas(sit_id):
    s = POR_ID.get(sit_id)
    escolhas = [(p["texto"], p["id"]) for p in s["perguntas"]] if s else []
    modalidade_visible = sit_id == "saude_mental"
    return (
        gr.update(choices=escolhas, value=[], visible=bool(escolhas)),
        gr.update(value=None, visible=modalidade_visible),
    )


def sugerir(texto):
    s, conf = motor.sugerir_situacao(texto, REGRAS)

    if s is None:
        return (
            gr.update(),
            "Não entendi. Escolha uma opção no menu.",
            gr.update(choices=[], value=[], visible=False),
            gr.update(value=None, visible=False),
        )

    escolhas = [(p["texto"], p["id"]) for p in s.get("perguntas", [])]

    return (
        gr.update(value=s["id"]),
        (
            f"Parece ser: **{s['titulo']}** (confiança {conf}). "
            "Confira a opção e responda a pergunta abaixo, se houver."
        ),
        gr.update(
            choices=escolhas,
            value=[],
            visible=bool(escolhas)
        )
        ,
        gr.update(value=None, visible=s["id"] == "saude_mental"),
    )


def orientar(bairro, sit_id, marcadas, modalidade_caps):
    if not bairro or not sit_id:
        return "Escolha o bairro e a situação."

    resposta, conf = motor.responder(
        POR_ID[sit_id],
        marcadas or [],
        bairro,
        UNIDADES,
        modalidade_caps=modalidade_caps,
    )
    motor.registrar(sit_id, conf)
    return resposta


with gr.Blocks(title="Orientação SUS (protótipo)") as app:
    gr.Markdown("# Orientação SUS — protótipo\n" + motor.AVISO)
    gr.Markdown("## Onde você está?")
    bairro = gr.Dropdown(motor.bairros(UNIDADES), label="Seu bairro")
    texto = gr.Textbox(label="Descreva o que você precisa (opcional, aperte Enter)")
    msg = gr.Markdown()
    sit = gr.Dropdown([(s["titulo"], s["id"]) for s in REGRAS], label="O que você precisa?")
    marcas = gr.CheckboxGroup([], label="Marque o que se aplica", visible=False)
    modalidade_caps = gr.Dropdown(
        [
            ("Saúde mental para adulto", "ADULTO"),
            ("Saúde mental para criança ou adolescente", "IJ"),
            ("Atendimento relacionado ao uso de álcool ou outras drogas", "AD"),
            ("Não sei qual escolher", "NAO_SEI"),
        ],
        label="Que atendimento você procura?",
        visible=False,
        value=None,
    )
    botao = gr.Button("Orientar")
    saida = gr.Markdown()

    texto.submit(sugerir, texto, [sit, msg, marcas, modalidade_caps])
    sit.change(perguntas, sit, [marcas, modalidade_caps])
    botao.click(orientar, [bairro, sit, marcas, modalidade_caps], saida)

if __name__ == "__main__":
    app.launch()
