import json
import math
import os
import tempfile
import threading
import unicodedata
from pathlib import Path

import requests
from dotenv import load_dotenv

RAIZ = Path(__file__).resolve().parent.parent
CACHE_PATH = RAIZ / "data" / "geocodificacao_unidades.json"
ORS_GEOCODE_URL = "https://api.openrouteservice.org/geocode/search"
ORS_MATRIX_URL = "https://api.openrouteservice.org/v2/matrix/driving-car"
HTTP_TIMEOUT = 10
MAX_CANDIDATAS = 20
MAX_RESULTADOS = 5
MAX_BAIRRO = 10

_CACHE_BAIRROS = {}
_CACHE_UNIDADES = None
_LOCK = threading.RLock()


def _chave_api():
    load_dotenv(RAIZ / ".env")
    return os.getenv("OPENROUTESERVICE_API_KEY", "").strip()


def api_configurada():
    return bool(_chave_api())


def _texto(valor):
    if valor is None:
        return ""
    texto = str(valor).strip()
    if not texto or texto.casefold() in {"nan", "none"}:
        return ""
    return texto


def _normalizar(texto):
    return unicodedata.normalize("NFKD", _texto(texto)).casefold()


def validar_coordenadas(coordenadas):
    """Valida e retorna uma tupla (longitude, latitude), ordem usada pelo ORS."""
    if not isinstance(coordenadas, (list, tuple)) or len(coordenadas) != 2:
        return None
    try:
        longitude, latitude = map(float, coordenadas)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(longitude) or not math.isfinite(latitude):
        return None
    if not (-180 <= longitude <= 180 and -90 <= latitude <= 90):
        return None
    if not (-53.5 < longitude < -44 and -25.5 < latitude < -19.5):
        return None
    return longitude, latitude


def _coordenadas_feature(feature):
    if not isinstance(feature, dict):
        return None
    geometry = feature.get("geometry")
    if not isinstance(geometry, dict):
        return None
    return validar_coordenadas(geometry.get("coordinates"))


def _consultar_geocode(texto):
    chave = _chave_api()
    if not chave:
        return None, "temporary"
    try:
        resposta = requests.get(
            ORS_GEOCODE_URL,
            params={
                "api_key": chave,
                "text": texto,
                "size": 1,
                "boundary.country": "BR",
            },
            timeout=HTTP_TIMEOUT,
        )
        resposta.raise_for_status()
        dados = resposta.json()
    except requests.HTTPError as erro:
        status = getattr(erro.response, "status_code", None)
        return None, "not_found" if status in {400, 404} else "temporary"
    except (requests.RequestException, ValueError):
        return None, "temporary"
    features = dados.get("features") if isinstance(dados, dict) else None
    if not isinstance(features, list) or not features:
        return None, "not_found"
    coordenadas = _coordenadas_feature(features[0])
    return (coordenadas, "ok") if coordenadas is not None else (None, "not_found")


def geocodificar_bairro(bairro):
    consulta = f"{_texto(bairro)}, São Paulo, SP, Brasil"
    chave = _normalizar(consulta)
    if not api_configurada() or not _texto(bairro):
        return None
    with _LOCK:
        if chave not in _CACHE_BAIRROS:
            _CACHE_BAIRROS[chave] = _consultar_geocode(consulta)[0]
        return _CACHE_BAIRROS[chave]


def montar_endereco_unidade(unidade):
    logradouro = _texto(unidade.get("NO_LOGRADOURO"))
    numero = _texto(unidade.get("NU_ENDERECO"))
    bairro = _texto(unidade.get("NO_BAIRRO"))
    nome = _texto(unidade.get("NOME"))
    cep = _texto(unidade.get("cep"))
    municipio = _texto(unidade.get("municipio")) or "São Paulo"
    uf = _texto(unidade.get("uf")) or "SP"

    partes = []
    if logradouro:
        partes.append(f"{logradouro}, {numero}" if numero else logradouro)
    if bairro:
        partes.append(bairro)
    if nome and not logradouro:
        partes.insert(0, nome)
    if cep:
        partes.append(cep)
    partes.extend([municipio, uf, "Brasil"])
    return ", ".join(partes)


def _chave_unidade(unidade):
    cnes = _texto(unidade.get("CO_CNES"))
    if cnes:
        return cnes
    namespace = _texto(unidade.get("cache_namespace")) or "unidade"
    identificador = _texto(unidade.get("id_local"))
    base = identificador or montar_endereco_unidade(unidade)
    return f"{namespace}:{_normalizar(base)}"


def _carregar_cache():
    global _CACHE_UNIDADES
    if _CACHE_UNIDADES is not None:
        return _CACHE_UNIDADES
    try:
        with CACHE_PATH.open(encoding="utf-8") as arquivo:
            dados = json.load(arquivo)
    except (OSError, json.JSONDecodeError):
        dados = {}
    _CACHE_UNIDADES = dados if isinstance(dados, dict) else {}
    return _CACHE_UNIDADES


def _salvar_cache():
    cache = _CACHE_UNIDADES or {}
    CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    fd, caminho = tempfile.mkstemp(
        prefix=f"{CACHE_PATH.name}.", suffix=".tmp", dir=CACHE_PATH.parent
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as arquivo:
            json.dump(cache, arquivo, ensure_ascii=False, indent=2)
        os.replace(caminho, CACHE_PATH)
    except OSError:
        try:
            os.unlink(caminho)
        except OSError:
            pass


def geocodificar_unidade(unidade):
    global _CACHE_UNIDADES
    if not api_configurada():
        return None
    endereco = montar_endereco_unidade(unidade)
    chave = _chave_unidade(unidade)
    with _LOCK:
        cache = _carregar_cache()
        registro = cache.get(chave)
        if isinstance(registro, dict) and registro.get("status") == "nao_encontrado":
            return None
        if isinstance(registro, dict) and registro.get("status") == "ok":
            coordenadas = validar_coordenadas(
                (registro.get("longitude"), registro.get("latitude"))
            )
            if coordenadas is not None:
                return coordenadas

        coordenadas, status = _consultar_geocode(endereco)
        endereco_sem_cep = _texto(unidade.get("endereco_sem_cep"))
        if coordenadas is None and status != "temporary" and endereco_sem_cep:
            coordenadas, status = _consultar_geocode(endereco_sem_cep)
        if coordenadas is None and status != "temporary" and _texto(unidade.get("NOME")):
            coordenadas, status = _consultar_geocode(
                f"{_texto(unidade.get('NOME'))}, {_texto(unidade.get('NO_BAIRRO'))}, "
                "São Paulo, SP, Brasil"
            )
        cache_alterado = False
        if coordenadas is None and status != "temporary":
            cache[chave] = {
                "endereco_consultado": endereco,
                "status": "nao_encontrado",
            }
            cache_alterado = True
        elif coordenadas is not None:
            cache[chave] = {
                "endereco_consultado": endereco,
                "longitude": coordenadas[0],
                "latitude": coordenadas[1],
                "status": "ok",
            }
            cache_alterado = True
        _CACHE_UNIDADES = cache
        if cache_alterado:
            _salvar_cache()
        return coordenadas


def calcular_rotas(origem, destinos):
    """Retorna (distância_metros, duração_segundos) na ordem dos destinos."""
    chave = _chave_api()
    origem = validar_coordenadas(origem)
    destinos = [validar_coordenadas(destino) for destino in destinos]
    if not chave or origem is None or not destinos or any(
        destino is None for destino in destinos
    ):
        return None
    try:
        resposta = requests.post(
            ORS_MATRIX_URL,
            headers={"Authorization": chave, "Content-Type": "application/json"},
            json={
                "locations": [list(origem)] + [list(destino) for destino in destinos],
                "sources": [0],
                "destinations": list(range(1, len(destinos) + 1)),
                "metrics": ["distance", "duration"],
            },
            timeout=HTTP_TIMEOUT,
        )
        resposta.raise_for_status()
        dados = resposta.json()
    except (requests.RequestException, ValueError):
        return None

    distancias = dados.get("distances") if isinstance(dados, dict) else None
    duracoes = dados.get("durations") if isinstance(dados, dict) else None
    if not isinstance(distancias, list) or not distancias or not isinstance(
        distancias[0], list
    ):
        return None
    linha_distancias = distancias[0]
    linha_duracoes = duracoes[0] if isinstance(duracoes, list) and duracoes else []
    resultados = []
    for indice, distancia in enumerate(linha_distancias):
        try:
            distancia = float(distancia)
            duracao = (
                float(linha_duracoes[indice])
                if indice < len(linha_duracoes)
                and linha_duracoes[indice] is not None
                else None
            )
        except (TypeError, ValueError):
            resultados.append(None)
            continue
        if not math.isfinite(distancia) or distancia < 0:
            resultados.append(None)
        else:
            resultados.append((distancia, duracao))
    return resultados if len(resultados) == len(destinos) else None
